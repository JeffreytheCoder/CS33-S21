/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_181(unsigned *p)
{
    *p = 1476812111U;
}

unsigned getval_384()
{
    return 3347662911U;
}

unsigned addval_459(unsigned x)
{
    return x + 2546176080U;
}

unsigned getval_110()
{
    return 3251079496U;
}

unsigned getval_383()
{
    return 3281016853U;
}

unsigned getval_435()
{
    return 2425393496U;
}

void setval_304(unsigned *p)
{
    *p = 3267856712U;
}

unsigned getval_425()
{
    return 3347662922U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_455(unsigned x)
{
    return x + 3767091266U;
}

void setval_498(unsigned *p)
{
    *p = 2430634313U;
}

void setval_393(unsigned *p)
{
    *p = 3284305934U;
}

unsigned addval_269(unsigned x)
{
    return x + 3222851977U;
}

unsigned getval_295()
{
    return 3526935177U;
}

void setval_246(unsigned *p)
{
    *p = 3375940235U;
}

unsigned addval_201(unsigned x)
{
    return x + 3676357256U;
}

void setval_240(unsigned *p)
{
    *p = 3221802697U;
}

unsigned addval_217(unsigned x)
{
    return x + 3375944073U;
}

unsigned getval_288()
{
    return 3352201631U;
}

unsigned addval_477(unsigned x)
{
    return x + 2425668233U;
}

void setval_364(unsigned *p)
{
    *p = 3674787337U;
}

unsigned addval_140(unsigned x)
{
    return x + 3372797577U;
}

void setval_436(unsigned *p)
{
    *p = 3531919785U;
}

unsigned getval_223()
{
    return 180604553U;
}

unsigned getval_131()
{
    return 3224424073U;
}

unsigned addval_430(unsigned x)
{
    return x + 2430650696U;
}

void setval_351(unsigned *p)
{
    *p = 3523789449U;
}

void setval_256(unsigned *p)
{
    *p = 3375944065U;
}

unsigned addval_250(unsigned x)
{
    return x + 3281047945U;
}

void setval_349(unsigned *p)
{
    *p = 3252717896U;
}

unsigned getval_282()
{
    return 2464188744U;
}

unsigned addval_328(unsigned x)
{
    return x + 3374367385U;
}

void setval_125(unsigned *p)
{
    *p = 3375944075U;
}

unsigned getval_352()
{
    return 3767224549U;
}

unsigned getval_169()
{
    return 2496563519U;
}

unsigned getval_261()
{
    return 3286272328U;
}

unsigned addval_448(unsigned x)
{
    return x + 3682914761U;
}

unsigned addval_417(unsigned x)
{
    return x + 3223375369U;
}

unsigned addval_152(unsigned x)
{
    return x + 3281044107U;
}

void setval_216(unsigned *p)
{
    *p = 3767093433U;
}

unsigned addval_467(unsigned x)
{
    return x + 3670266253U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
